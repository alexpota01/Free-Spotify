# Free Spotify | Stage 3 playback compatibility update

This keeps the existing Stage 3 interface, Flask endpoints and database. It changes only YouTube iframe initialization to explicitly set `referrerpolicy="strict-origin-when-cross-origin"` on the real iframe and adds clearer playback errors.

## GitHub Codespaces
1. Download ZIP and upload into the repository root.
2. In the Codespaces terminal: `unzip -o free_spotify_player_fix.zip`
3. Run `source .venv/bin/activate && python -m pip install -r requirements.txt && python app.py`. Restart the Flask process first if already running.
4. Hard refresh the browser with Ctrl+Shift+R. Search a song, click it, and try the **visible** video player.
5. If you see Error 153, inspect Chrome DevTools > Network > the `youtube.com/embed/...` request > Request Headers > `Referer`. If missing, the browser/forwarding environment is suppressing the required header. Try the same Codespaces app in another browser or a normal HTTPS deployment. This fix cannot force browsers/proxies to send forbidden headers.
6. Errors 101/150 mean embedding is disabled for that particular video; try another. Autoplay on iOS may require tapping the visible video player.

This version still uses YouTube's *official visible* IFrame Player for online content, not direct Spotify or YouTube audio extraction. Search remains powered by `ytmusicapi`. Local music uses HTML5 audio. Do not set Codespaces port 5000 to Public because this app has no authentication.

`music.db` and `uploads/` are NOT included in the archive. Leave them untouched.
